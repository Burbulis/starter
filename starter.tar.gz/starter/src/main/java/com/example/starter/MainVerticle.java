package com.example.starter;
import io.vertx.core.http.HttpHeaders;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.core.http.HttpServer;
import java.io.IOException;

public class MainVerticle extends AbstractVerticle {

  private JsonObject jsonObj;
  private String parameter;

  private String  extract_json(String str)
  { 
    int first_ = str.indexOf("{");
    int last_ = str.indexOf("}");
    return (str.substring(first_,last_+1));
  }

  @Override
  public void start(Promise<Void> startPromise) throws Exception {
 
  vertx.fileSystem().readFile("test.json", result -> {
  if (result.succeeded()) {
        System.out.println(result.result().toString());
        jsonObj = new JsonObject(result.result().toString());   
        System.out.println("test:"+jsonObj.getString("url_mail"));
	    } else {
        System.err.println("Fucking fuck! ..." + result.cause());
	    }
	});
	 Router router = Router.router(vertx);
  router.get("/").handler(rc -> {rc.response().putHeader("content-type", "text/html").end("xxx");});
  router.get("/:src").handler(rc->{
  String conf = extract_json(rc.pathParam("src"));
 // rc.response().end("conf: "+conf);
  System.out.println("conf:"+ conf);
  JsonObject jsonO = new JsonObject(conf);   
  String get_param = jsonO.getString("name");
  System.out.println("test_obj:"+get_param);
//  parameter = "<html><head><title></title><meta http-equiv='refresh' content='3;url='"+jsonObj.getString(get_param)+"'/><body></body></html>";
  parameter = "<html><script>window.location.href = '"+jsonObj.getString(get_param)+"'</script>";
  System.out.println(parameter);
  rc.response().putHeader("content-type", "text/html").end(parameter);    
   }
  );
 
  HttpServer x_server = vertx.createHttpServer();
  x_server.requestHandler(request -> {
            }
        );

  x_server.requestHandler(router).listen(8080);
  startPromise.complete();
  }
}
