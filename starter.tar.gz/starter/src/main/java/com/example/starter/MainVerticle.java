package com.example.starter;
//import io.vertx.core.http;
import io.vertx.core.http.HttpHeaders;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.ext.web.Router;
//import io.vertx.ext.web.RoutingContext;
import io.vertx.core.http.HttpServer;
import java.io.IOException;

public class MainVerticle extends AbstractVerticle {
  @Override
  public void start(Promise<Void> startPromise) throws Exception {
 
 HttpServer x_server = vertx.createHttpServer();
  x_server.requestHandler(request -> {
//  System.out.println("incoming request!");
   request.response().putHeader("content-type", "text/html").end("<html><head><title></title><meta http-equiv='refresh' content='1;url=http://www.google.ru'/><body></body></html>");
         }
        );
  x_server.listen(8080);
  startPromise.complete();
  }
}
